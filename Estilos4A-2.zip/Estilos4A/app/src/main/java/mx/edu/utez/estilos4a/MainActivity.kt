package mx.edu.utez.estilos4a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//  Drawable - Shape Vector y Selector
// Son archivos XML\
//shape= cambia las formas rectangulo,linea ,ovalo
//Vector=
// selector = cambiar la aparencia a un control dependiendo de su estado
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}